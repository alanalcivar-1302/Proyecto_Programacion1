#include "funciones.h"

#include <stdio.h>
	

void opcionesUsuario(int *opcionEscoger, int rangoOpciones){
	
	while ((*opcionEscoger < 0) || (*opcionEscoger > rangoOpciones	)){
		printf("Opcion no valida, ingrese nuevamente (1-%d)\n",rangoOpciones);
		scanf("%d",opcionEscoger);
	}
};

int validacionCaracteres(char stringValidar[]){
	for (int i = 0; stringValidar[i] != "\0"; i++){
		if ((isalpha(stringValidar[i]) != 0) && (stringValidar[i] = '\0')){
			return 1;
		}
	}
	return 0;
}
	
void validacionNumerica(int *intValidar){
	while (scanf("%d",*intValidar) != 0)
		printf("La informaci�n ingresada es erronea, intente nuevamente\n");
}


int validarPlaca(char placa[]) {
	if (strlen(placa) != 8)
		return 0;
	
	for (int i = 0; i < 3; i++) {
		if (!isupper(placa[i])) 
			return 0;
	}
	if (placa[3] != '-') 
		return 0;
	
	for (int i = 4; i < 8; i++) {
		if (!isdigit(placa[i])) 
			return 0;
	}
	return 1;
}

void validacionEntradaNombre(char *stringValidar[]){
	int resultado;
	do{
		scanf("%s",*stringValidar);
		resultado = validacionCaracteres(stringValidar);
	}while(resultado != 0);
	
}

	
void validacionCedula(int *cedulaValidar){
	char cedulaStr[10];
	int intentos = 0;
	
	/*validacionNumerica(cedulaValidar);
	sprintf(cedulaStr,"%d",cedulaValidar);
	while (strlen(cedulaStr) != 10){
		printf("Cedula incompleta, ingrese nuevamente");
		validacionNumerica(cedulaValidarValidar);
		sprintf(cedulaStr,"%d",cedulaValidar);
	}
	*/
	do{
		if (intentos > 1){
			printf("Cedula incompleta, ingrese nuevamente");
		}
		validacionNumerica(*cedulaValidar);
		sprintf(cedulaStr,"%d",cedulaValidar);
		intentos++;
	}while((strlen(cedulaStr) != 10));
}
	
void pedirPlaca(char placa[]) {
	do {
		printf("Ingrese la placa (ej: ABC-1234): \n");
		fgets(placa, TAM_PLACA, stdin);
		placa[strcspn(placa, "\n")] = '\0';
		if (!validarPlaca(placa)) 
			printf("Placa invalida, intente de nuevo.\n");
	} while (!validarPlaca(placa));
}
	



