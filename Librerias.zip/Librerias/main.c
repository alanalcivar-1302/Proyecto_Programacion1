//#include <iostream>
//#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//funciones de la libreria
#include "archivoCabecera.h"

int main(){
	
	//Variables
	int opcion = 0;
	char cedulaBusqueda[TAM_CEDULA];
	datos person;
	FILE *archivoDatos;
	int nuevo_Pagomatricula = 1;
	
	//std::string 
	//string ruta = "C:\\Users\\nahin\\Documents\\Programacion1\\ProyectoProgramacion1\\Librerias\\datosVehiculos.txt";
	
	//std::ofstream archivo(ruta);
	
	//Bucle del men�, acabar� si el usuario ingresa el n�mero 5
	while (opcion != 5){
		
		menu();
		
		printf("�Qu� desea realizar? \n");
		scanf("%d",&opcion);
		
		//Limpiar el terminal
		system("cls");
		
		
		switch (opcion){
			case 1: 
				printf("-----Registro de vehiculos-----\n");
				
				archivoDatos = fopen("C:\\Users\\nahin\\Documents\\Programacion1\\ProyectoProgramacion1\\Librerias\\datosVehiculos.txt","a");
				
				//Ingreso de Datos y validaci�n
				clearInputBuffer();				
				pedirNombre(person.nombrePropietario);
				pedirCedula(person.numCedula);
				printf("Ingresar el modelo del veh�culo\n");
				scanf("%s",&person.modeloAuto);
				clearInputBuffer();      
				pedirPlaca(person.placa);
				printf("Ingresar el color del veh�culo\n");
				scanf("%s",&person.colorAuto);
				printf("Ingresar a�o del veh�culo\n");
				scanf("%d",&person.anioAuto);
				clearInputBuffer();
				
				//Ingreso de datos en el archivo txt
				fprintf(archivoDatos,"%s,%s,%s,%s,%s,%d\n",person.nombrePropietario, person.numCedula, person.modeloAuto, person.placa, person.colorAuto, person.anioAuto);
				fclose(archivoDatos);
				
				opcion = continuar();
				
				break;
				
			case 2:
				
				printf("-----Buscar veh�culo-----\n");
				
				printf("Ingresar el n�mero de c�dula del propietario del veh�culo que desea buscar\n");
				pedirCedula(cedulaBusqueda);
				//buscarVehiculo(cedulaBusqueda);
				opcion = continuar();
				break;
			case 3:
				
				printf("-----Consulta valor a pagar-----\n");
				
				while (nuevo_Pagomatricula) {
					int pagoAtiempo, hizo_revisionVehiculo, diasPago;
					float multasVehiculo, total_pagoMatricula ;
					
					printf("�Realiz� la revisi�n t�cnica? (1=S�, 0=No): \n");
					scanf("%d", &hizo_revisionVehiculo);
					
					printf("�Pag� la matr�cula a tiempo? (1=S�, 0=No): \n");
					scanf("%d", &pagoAtiempo);
					
					printf("�Cu�ntos d�as han pasado desde la notificaci�n?: \n");
					scanf("%d", &diasPago);
					
					printf("Valor total de multas (sin descuentos): $\n");
					scanf("%f", &multasVehiculo);
					
					//Total a pagar de la matr�cula
					total_pagoMatricula = calcularValormatricula(pagoAtiempo, hizo_revisionVehiculo, diasPago, multasVehiculo);
					
					if (total_pagoMatricula >= 0) {
						printf("\n--------------- COMPROBANTE DE MATRICULA ---------------\n");
						printf("Recuerde guardar el comprobante. \n");
						printf("Multas: $%.2f\n", multasVehiculo);
						printf("Total a pagar: $%.2f\n", total_pagoMatricula);
						printf("----------------------------------------------------------\n");
					}
					
					// Desea revisar nuevo pago?
					
					printf("\n�Desea procesar otro pago de matr�cula? (1 = S�, 0 = No): \n");
					scanf("%d", &nuevo_Pagomatricula);
				}
				opcion = continuar();
				break;
			case 4:
				printf("-----Agendamiento de citas -----\n");
				opcion = continuar();
				break;
			case 5:
				break;
		default:
			printf("Opci�n no valida\n");
			break;
		}
	}
	
	return 0;
}
	
	
